Link to the documentation:
https://andynameistaken.github.io/mkdocs_sample_plugin/